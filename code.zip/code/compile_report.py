"""Utility script to compile the LaTeX report into PDF."""

from __future__ import annotations

import subprocess
from pathlib import Path


if __name__ == "__main__":
    report_dir = Path(__file__).resolve().parents[1] / "report"
    tex_file = report_dir / "report.tex"

    cmd = ["pdflatex", "-interaction=nonstopmode", "report.tex"]
    for _ in range(2):
        subprocess.run(cmd, cwd=report_dir, check=True)

    print(f"Compiled PDF at: {report_dir / 'report.pdf'}")
