"""Coupled map lattice simulators and network constructors."""

from __future__ import annotations

import networkx as nx
import numpy as np

from map_model import local_map


def ring_adjacency(n_nodes: int) -> np.ndarray:
    """Build nearest-neighbor ring adjacency matrix."""

    adjacency = np.zeros((n_nodes, n_nodes), dtype=float)
    for i in range(n_nodes):
        adjacency[i, (i - 1) % n_nodes] = 1.0
        adjacency[i, (i + 1) % n_nodes] = 1.0
    return adjacency


def watts_strogatz_adjacency(n_nodes: int, k: int, p: float, seed: int) -> np.ndarray:
    """Build Watts-Strogatz adjacency matrix."""

    graph = nx.watts_strogatz_graph(n_nodes, k, p, seed=seed)
    return nx.to_numpy_array(graph, dtype=float)


def random_adjacency(n_nodes: int, edge_prob: float, seed: int) -> np.ndarray:
    """Build Erdos-Renyi random graph adjacency matrix."""

    graph = nx.erdos_renyi_graph(n_nodes, edge_prob, seed=seed)
    if not nx.is_connected(graph):
        largest_component = max(nx.connected_components(graph), key=len)
        graph = graph.subgraph(largest_component).copy()
        missing = n_nodes - graph.number_of_nodes()
        if missing > 0:
            for _ in range(missing):
                node_id = graph.number_of_nodes()
                graph.add_node(node_id)
                target = np.random.default_rng(seed + node_id).integers(0, max(node_id, 1))
                graph.add_edge(node_id, int(target))
    return nx.to_numpy_array(graph, nodelist=range(n_nodes), dtype=float)


def diffuse_step(x: np.ndarray, r: float, epsilon: float, adjacency: np.ndarray) -> np.ndarray:
    """One CML step with diffusive coupling on mapped states."""

    fx = local_map(x, r)
    degree = adjacency.sum(axis=1)
    degree_safe = np.where(degree > 0.0, degree, 1.0)
    neighbor_term = adjacency @ fx / degree_safe
    x_next = (1.0 - epsilon) * fx + epsilon * neighbor_term
    return np.maximum(x_next, 1e-12)


def simulate_cml(
    r: float,
    epsilon: float,
    adjacency: np.ndarray,
    n_steps: int,
    x0: np.ndarray,
) -> np.ndarray:
    """Simulate CML trajectory with shape (n_steps + 1, n_nodes)."""

    n_nodes = adjacency.shape[0]
    traj = np.zeros((n_steps + 1, n_nodes), dtype=float)
    traj[0] = np.maximum(x0, 1e-12)

    for t in range(n_steps):
        traj[t + 1] = diffuse_step(traj[t], r, epsilon, adjacency)

    if traj.shape[1] != n_nodes:
        raise RuntimeError("Internal shape mismatch in CML simulation.")
    return traj
