"""Local nonlinear map and single-map diagnostics for the CML study."""

from __future__ import annotations

import numpy as np
from scipy.special import lambertw


def local_map(x: np.ndarray | float, r: float) -> np.ndarray:
    """Compute f(x) = x^2 exp(r - x) for x > 0."""

    x_arr = np.asarray(x, dtype=float)
    return (x_arr**2) * np.exp(r - x_arr)


def map_derivative(x: np.ndarray | float, r: float) -> np.ndarray:
    """Derivative f'(x) used for stability and Lyapunov estimates."""

    x_arr = np.asarray(x, dtype=float)
    return np.exp(r - x_arr) * (2.0 * x_arr - x_arr**2)


def iterate_map(r: float, x0: float, n_steps: int) -> np.ndarray:
    """Iterate the local map trajectory x_n for a fixed r."""

    x = np.zeros(n_steps + 1, dtype=float)
    x[0] = max(x0, 1e-12)
    for i in range(n_steps):
        x[i + 1] = max(local_map(x[i], r), 1e-12)
    return x


def lyapunov_exponent(r: float, x0: float, n_transient: int, n_measure: int) -> float:
    """Estimate the maximal Lyapunov exponent of the single map."""

    x = max(x0, 1e-12)
    for _ in range(n_transient):
        x = max(local_map(x, r), 1e-12)

    accum = 0.0
    for _ in range(n_measure):
        deriv = np.abs(map_derivative(x, r))
        accum += np.log(max(float(deriv), 1e-12))
        x = max(local_map(x, r), 1e-12)

    return accum / float(n_measure)


def fixed_points(r: float) -> dict[str, float | None]:
    """Return nonnegative fixed points and their linear stability multipliers.

    Nonzero fixed points satisfy x e^{-x} = e^{-r}, which yields
    x* = -W_k(-e^{-r}) on real Lambert-W branches k in {0, -1} when available.
    """

    arg = -np.exp(-r)
    roots: list[float] = []

    for branch in (0, -1):
        w_val = lambertw(arg, branch)
        if np.isclose(w_val.imag, 0.0, atol=1e-10):
            x_star = float(-w_val.real)
            if x_star > 0 and all(abs(x_star - existing) > 1e-9 for existing in roots):
                roots.append(x_star)

    roots.sort()

    result: dict[str, float | None] = {
        "x0": 0.0,
        "x0_multiplier": 0.0,
        "x_minus": roots[0] if len(roots) >= 1 else None,
        "x_plus": roots[-1] if len(roots) >= 2 else None,
    }

    if result["x_minus"] is not None:
        x_minus = float(result["x_minus"])
        result["x_minus_multiplier"] = float(2.0 - x_minus)
    else:
        result["x_minus_multiplier"] = None

    if result["x_plus"] is not None:
        x_plus = float(result["x_plus"])
        result["x_plus_multiplier"] = float(2.0 - x_plus)
    else:
        result["x_plus_multiplier"] = None

    return result
