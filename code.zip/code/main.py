"""Main runner for nonlinear map and CML coursework project."""

from __future__ import annotations

from pathlib import Path

import numpy as np

from analysis import (
    cml_epsilon_sweep,
    cluster_coherence,
    fixed_point_stability_scan,
    lyapunov_scan,
    representative_single_map_series,
    single_map_bifurcation,
    size_effect_experiment,
)
from cml import random_adjacency, ring_adjacency, simulate_cml, watts_strogatz_adjacency
from plotting import (
    copy_for_report,
    plot_bifurcation,
    plot_cluster_bars,
    plot_heatmap,
    plot_lyapunov,
    plot_phase_space,
    plot_single_map_timeseries,
    plot_size_effect,
    plot_spatiotemporal,
    plot_sync_error_vs_epsilon,
    plot_topology_comparison,
    save_fig,
    set_style,
)


def ensure_dirs(base: Path) -> dict[str, Path]:
    """Create expected output directories and return path dictionary."""

    paths = {
        "data": base / "data",
        "plots": base / "plots",
        "figures": base / "figures",
        "report_fig": base / "report" / "figures",
    }
    for path in paths.values():
        path.mkdir(parents=True, exist_ok=True)
    return paths


def run() -> None:
    set_style()
    project_root = Path(__file__).resolve().parents[1]
    paths = ensure_dirs(project_root)

    rng = np.random.default_rng(1234)

    r_values = np.linspace(1.0, 3.0, 800)
    r_probe = [1.1, 1.6, 2.2, 2.8]

    single_df = representative_single_map_series(r_probe, x0=1.2, n_steps=400)
    bif_df = single_map_bifurcation(r_values, x0=1.2, n_transient=450, n_keep=70)
    lyap_df = lyapunov_scan(r_values, x0=1.2, n_transient=450, n_measure=600)
    fp_df = fixed_point_stability_scan(np.linspace(1.0, 3.0, 300))

    single_df.to_csv(paths["data"] / "single_map_timeseries.csv", index=False)
    bif_df.to_csv(paths["data"] / "bifurcation_data.csv", index=False)
    lyap_df.to_csv(paths["data"] / "lyapunov_scan.csv", index=False)
    fp_df.to_csv(paths["data"] / "fixed_point_stability.csv", index=False)

    fig_single = paths["plots"] / "single_map_timeseries.png"
    fig_phase = paths["plots"] / "phase_space_r_2p8.png"
    fig_bif = paths["plots"] / "bifurcation_diagram.png"
    fig_lyap = paths["plots"] / "lyapunov_spectrum.png"

    save_fig(plot_single_map_timeseries(single_df), fig_single)
    save_fig(plot_phase_space(single_df, r_value=2.8), fig_phase)
    save_fig(plot_bifurcation(bif_df), fig_bif)
    save_fig(plot_lyapunov(lyap_df), fig_lyap)

    n_nodes = 40
    n_steps = 250
    r_cml = 2.4
    epsilon_values = np.linspace(0.0, 1.0, 11)
    x0 = 0.8 + 0.4 * rng.random(n_nodes)

    ring_adj = ring_adjacency(n_nodes)
    sw_adj = watts_strogatz_adjacency(n_nodes, k=4, p=0.1, seed=321)
    rnd_adj = random_adjacency(n_nodes, edge_prob=4.0 / n_nodes, seed=654)

    ring_sync_df = cml_epsilon_sweep(ring_adj, r=r_cml, epsilon_values=epsilon_values, n_steps=n_steps, x0=x0)
    sw_sync_df = cml_epsilon_sweep(sw_adj, r=r_cml, epsilon_values=epsilon_values, n_steps=n_steps, x0=x0)
    rnd_sync_df = cml_epsilon_sweep(rnd_adj, r=r_cml, epsilon_values=epsilon_values, n_steps=n_steps, x0=x0)

    ring_sync_df.to_csv(paths["data"] / "sync_vs_epsilon_ring.csv", index=False)
    sw_sync_df.to_csv(paths["data"] / "sync_vs_epsilon_small_world.csv", index=False)
    rnd_sync_df.to_csv(paths["data"] / "sync_vs_epsilon_random.csv", index=False)

    save_fig(plot_sync_error_vs_epsilon(ring_sync_df), paths["plots"] / "sync_vs_epsilon_ring.png")
    save_fig(
        plot_topology_comparison(
            {
                "Ring": ring_sync_df,
                "Small-world": sw_sync_df,
                "Random": rnd_sync_df,
            }
        ),
        paths["plots"] / "topology_sync_comparison.png",
    )

    eps_no, eps_partial, eps_full = 0.1, 0.45, 0.9
    traj_no = simulate_cml(r=r_cml, epsilon=eps_no, adjacency=ring_adj, n_steps=n_steps, x0=x0)
    traj_partial = simulate_cml(r=r_cml, epsilon=eps_partial, adjacency=ring_adj, n_steps=n_steps, x0=x0)
    traj_full = simulate_cml(r=r_cml, epsilon=eps_full, adjacency=ring_adj, n_steps=n_steps, x0=x0)

    np.savetxt(paths["data"] / "traj_ring_no_sync.csv", traj_no, delimiter=",")
    np.savetxt(paths["data"] / "traj_ring_partial_sync.csv", traj_partial, delimiter=",")
    np.savetxt(paths["data"] / "traj_ring_full_sync.csv", traj_full, delimiter=",")

    save_fig(plot_spatiotemporal(traj_no, f"Spatiotemporal plot (ring, epsilon={eps_no:.2f})"), paths["plots"] / "spatiotemporal_no_sync.png")
    save_fig(
        plot_spatiotemporal(traj_partial, f"Spatiotemporal plot (ring, epsilon={eps_partial:.2f})"),
        paths["plots"] / "spatiotemporal_partial_sync.png",
    )
    save_fig(plot_spatiotemporal(traj_full, f"Spatiotemporal plot (ring, epsilon={eps_full:.2f})"), paths["plots"] / "spatiotemporal_full_sync.png")
    save_fig(plot_heatmap(traj_full, "Heatmap of node states in full synchronization regime"), paths["plots"] / "heatmap_full_sync.png")

    cluster_df = cluster_coherence(traj_partial, n_clusters=5)
    cluster_df.to_csv(paths["data"] / "cluster_sync_metrics.csv", index=False)
    save_fig(plot_cluster_bars(cluster_df), paths["plots"] / "cluster_sync_profile.png")

    size_df = size_effect_experiment(sizes=[30, 50, 80, 120], r=r_cml, epsilon=0.65, n_steps=220, seed=42)
    size_df.to_csv(paths["data"] / "size_effects.csv", index=False)
    save_fig(plot_size_effect(size_df), paths["plots"] / "size_effects.png")

    report_figs = [
        fig_single,
        fig_phase,
        fig_bif,
        fig_lyap,
        paths["plots"] / "sync_vs_epsilon_ring.png",
        paths["plots"] / "topology_sync_comparison.png",
        paths["plots"] / "spatiotemporal_no_sync.png",
        paths["plots"] / "spatiotemporal_partial_sync.png",
        paths["plots"] / "spatiotemporal_full_sync.png",
        paths["plots"] / "heatmap_full_sync.png",
        paths["plots"] / "cluster_sync_profile.png",
        paths["plots"] / "size_effects.png",
    ]
    copy_for_report(report_figs, paths["report_fig"])

    # Duplicate major figures to the top-level figures directory as requested.
    copy_for_report(report_figs, paths["figures"])

    print("All simulations completed.")
    print(f"Data saved to: {paths['data']}")
    print(f"Plots saved to: {paths['plots']}")
    print(f"Report figures saved to: {paths['report_fig']}")


if __name__ == "__main__":
    run()
