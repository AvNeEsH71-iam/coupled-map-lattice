"""
=============================================================================
Part II (Take-home): Coupled Maps — Ricker-type Local Map
=============================================================================
Course: Modeling Complex Systems

Local map:
    x_{n+1} = x_n^2 * exp(r - x_n),    x > 0,  r ∈ [1, 3]

This is a Ricker map (used in population dynamics / ecology).
We explore:
  A. Single-map dynamics  — fixed points, bifurcation diagram, Lyapunov exponent
  B. Ring CML             — diffusive coupling on a 1D ring
  C. WS Small-world CML   — coupling via WS adjacency matrix
  D. Scale-free CML       — coupling via Barabási–Albert network
  E. Synchronisation      — order parameter vs coupling ε and r
  F. Spatiotemporal chaos  — space-time plots, correlation, entropy
  G. Pattern formation     — clustering, chimera-like states

=============================================================================
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import networkx as nx
from mpl_toolkits.axes_grid1 import make_axes_locatable

# ─────────────────────────────────────────────────────────────────────────────
# GLOBAL SETTINGS
# ─────────────────────────────────────────────────────────────────────────────
np.random.seed(42)
plt.rcParams.update({
    'figure.dpi': 130,
    'font.size': 11,
    'axes.spines.top': False,
    'axes.spines.right': False,
    'axes.grid': True,
    'grid.alpha': 0.25,
})

# ─────────────────────────────────────────────────────────────────────────────
# CORE: Local Ricker map and its derivative
# ─────────────────────────────────────────────────────────────────────────────

def ricker(x, r):
    """
    Local map:  f(x) = x^2 * exp(r - x)
    Defined for x > 0.
    """
    return x**2 * np.exp(r - x)


def ricker_deriv(x, r):
    """
    f'(x) = x * exp(r - x) * (2 - x)
    Used for Lyapunov exponent and fixed-point stability.
    """
    return x * np.exp(r - x) * (2 - x)


def ricker_fixed_points(r):
    """
    Non-trivial fixed point: x* = f(x*) = x*^2 exp(r - x*)
    → 1 = x* exp(r - x*)  → x* exp(-x*) = exp(-r)
    Numerically: solve x - x^2 exp(r-x) = 0 for x > 0, x ≠ 0.
    Non-zero fixed point: x* satisfies x* exp(r - x*) = 1
    → Lambert W:  x* = W(exp(r))  [not always expressible simply]
    We solve numerically.
    """
    from scipy.optimize import brentq
    # f(x) - x = 0  ↔  x^2 exp(r-x) - x = 0  ↔  x(x exp(r-x) - 1) = 0
    # Non-trivial: x exp(r-x) = 1
    def eq(x): return x * np.exp(r - x) - 1
    try:
        xstar = brentq(eq, 0.01, 20)
    except Exception:
        xstar = None
    return xstar


# =============================================================================
# EXPERIMENT A — Single-map analysis
# =============================================================================

def experiment_A_single_map():
    """
    A1. Bifurcation diagram: iterate f(x;r) for r ∈ [1,3], plot attractor.
    A2. Lyapunov exponent λ(r) = lim (1/N) Σ log|f'(x_n)|
    A3. Phase portrait / cobweb diagram for selected r values.
    A4. Fixed points and their stability.
    """
    print("\n[A] Single-map dynamics")

    # ── A1 + A2: Bifurcation + Lyapunov ──────────────────────────────────────
    r_vals   = np.linspace(1.0, 3.0, 1200)
    N_trans  = 500     # transient (discard)
    N_plot   = 200     # points to plot per r
    N_lyap   = 2000    # total iterations for Lyapunov

    bif_r, bif_x = [], []
    lyap = []

    for r in r_vals:
        # bifurcation
        x = 1.5
        for _ in range(N_trans):
            x = ricker(x, r)
        xs = []
        for _ in range(N_plot):
            x = ricker(x, r)
            xs.append(x)
        bif_r.extend([r] * N_plot)
        bif_x.extend(xs)

        # Lyapunov exponent
        x = 1.5
        lam = 0.0
        for _ in range(N_lyap):
            df = abs(ricker_deriv(x, r))
            lam += np.log(df + 1e-16)
            x = ricker(x, r)
        lyap.append(lam / N_lyap)

    lyap = np.array(lyap)

    fig, axes = plt.subplots(2, 1, figsize=(12, 9), sharex=True)
    fig.suptitle('Single Ricker Map  $x_{n+1} = x_n^2 \\exp(r - x_n)$',
                 fontsize=14, fontweight='bold')

    axes[0].scatter(bif_r, bif_x, s=0.3, c='steelblue', alpha=0.4, rasterized=True)
    axes[0].set_ylabel('Attractor  $x^*$')
    axes[0].set_title('Bifurcation diagram')
    axes[0].set_ylim(0, None)

    # Mark fixed points
    fp_r, fp_x = [], []
    for r in np.linspace(1, 3, 300):
        xs = ricker_fixed_points(r)
        if xs: fp_r.append(r); fp_x.append(xs)
    axes[0].plot(fp_r, fp_x, 'r-', lw=1.2, label='Fixed point $x^*$', zorder=5)
    axes[0].legend(fontsize=9, loc='upper left')

    axes[1].plot(r_vals, lyap, color='darkviolet', lw=1.2, label='λ(r)')
    axes[1].axhline(0, color='crimson', ls='--', lw=1, label='λ = 0')
    axes[1].fill_between(r_vals, lyap, 0,
                         where=(lyap > 0), alpha=0.2, color='crimson',
                         label='Chaotic (λ > 0)')
    axes[1].fill_between(r_vals, lyap, 0,
                         where=(lyap < 0), alpha=0.2, color='steelblue',
                         label='Stable (λ < 0)')
    axes[1].set_xlabel('Parameter  r')
    axes[1].set_ylabel('Lyapunov exponent  λ')
    axes[1].set_title('Lyapunov exponent λ(r)')
    axes[1].legend(fontsize=9)

    plt.tight_layout()
    plt.savefig('/mnt/user-data/outputs/A1_bifurcation_lyapunov.png', bbox_inches='tight')
    plt.show()

    # ── A3: Cobweb diagrams for 4 r values ───────────────────────────────────
    r_cobweb = [1.5, 2.0, 2.5, 2.9]
    fig, axes = plt.subplots(2, 2, figsize=(12, 10))
    fig.suptitle('Cobweb diagrams — Ricker map', fontsize=13, fontweight='bold')

    for ax, r in zip(axes.flat, r_cobweb):
        xmax = max(4.0, r + 1)
        x_line = np.linspace(0.01, xmax, 500)
        ax.plot(x_line, ricker(x_line, r), color='steelblue', lw=2, label=f'f(x), r={r}')
        ax.plot(x_line, x_line, 'k--', lw=1, label='y = x')

        # Cobweb
        x = 0.5
        for _ in range(300):
            x = ricker(x, r)   # warm up
        xc = x
        for _ in range(60):
            xn = ricker(xc, r)
            ax.plot([xc, xc], [xc, xn], color='crimson', lw=0.8, alpha=0.7)
            ax.plot([xc, xn], [xn, xn], color='crimson', lw=0.8, alpha=0.7)
            xc = xn

        lam_r = lyap[np.argmin(abs(r_vals - r))]
        ax.set_xlim(0, xmax); ax.set_ylim(0, xmax)
        ax.set_xlabel('$x_n$'); ax.set_ylabel('$x_{n+1}$')
        ax.set_title(f'r = {r}   |   λ = {lam_r:.3f}')
        ax.legend(fontsize=8)

    plt.tight_layout()
    plt.savefig('/mnt/user-data/outputs/A2_cobweb.png', bbox_inches='tight')
    plt.show()
    print("  → Saved: A1_bifurcation_lyapunov.png, A2_cobweb.png")


# =============================================================================
# EXPERIMENT B — Ring CML (1D diffusive coupling)
# =============================================================================

def cml_ring_step(x, r, eps):
    """
    One time step of ring CML with diffusive coupling.

    x_{i,n+1} = (1 - ε) f(x_{i,n}) + (ε/2) [f(x_{i-1,n}) + f(x_{i+1,n})]

    Parameters
    ----------
    x   : array (N,) — current state of all sites
    r   : float      — local map parameter
    eps : float      — coupling strength ∈ [0, 1]
    """
    fx = ricker(x, r)                          # local map applied to all sites
    fx_left  = np.roll(fx,  1)                 # left neighbour (periodic)
    fx_right = np.roll(fx, -1)                 # right neighbour (periodic)
    return (1 - eps) * fx + (eps / 2) * (fx_left + fx_right)


def experiment_B_ring_CML():
    """
    B1. Space-time plot for ring CML at various (r, ε).
    B2. Synchronisation order parameter vs ε for different r.
    B3. Spatial correlation function C(d).
    """
    print("\n[B] Ring CML (1D diffusive coupling)")

    N      = 100
    N_trans = 500
    N_iter  = 300

    # ── B1: Space-time plots ──────────────────────────────────────────────────
    configs = [
        (2.0, 0.1, 'r=2.0, ε=0.1\n(period-2, weakly coupled)'),
        (2.0, 0.5, 'r=2.0, ε=0.5\n(synchronised)'),
        (2.9, 0.1, 'r=2.9, ε=0.1\n(spatiotemporal chaos)'),
        (2.9, 0.5, 'r=2.9, ε=0.5\n(chaos + coupling)'),
    ]

    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    fig.suptitle('Space-time plots — Ring CML', fontsize=13, fontweight='bold')

    for ax, (r, eps, title) in zip(axes.flat, configs):
        x = np.random.uniform(0.5, 2.5, N)
        for _ in range(N_trans):
            x = cml_ring_step(x, r, eps)
        XT = []
        for _ in range(N_iter):
            x = cml_ring_step(x, r, eps)
            XT.append(x.copy())
        XT = np.array(XT).T   # shape (N, N_iter)
        im = ax.imshow(XT, aspect='auto', origin='lower',
                       extent=[0, N_iter, 0, N], cmap='inferno')
        ax.set_xlabel('Time  n'); ax.set_ylabel('Site  i')
        ax.set_title(title, fontsize=10)
        plt.colorbar(im, ax=ax, label='$x_i$')

    plt.tight_layout()
    plt.savefig('/mnt/user-data/outputs/B1_spacetime_ring.png', bbox_inches='tight')
    plt.show()

    # ── B2: Synchronisation vs ε ──────────────────────────────────────────────
    r_list   = [1.8, 2.2, 2.6, 2.9]
    eps_vals = np.linspace(0, 1, 40)
    colors   = plt.cm.plasma(np.linspace(0.1, 0.9, len(r_list)))
    N_trans2, N_iter2 = 600, 400

    fig, ax = plt.subplots(figsize=(9, 5))
    for r, col in zip(r_list, colors):
        sync = []
        for eps in eps_vals:
            x = np.random.uniform(0.5, 2.5, N)
            for _ in range(N_trans2):
                x = cml_ring_step(x, r, eps)
            variances = []
            for _ in range(N_iter2):
                x = cml_ring_step(x, r, eps)
                variances.append(np.var(x))
            sync.append(np.mean(variances))
        ax.semilogy(eps_vals, np.array(sync) + 1e-12, '-o', ms=3,
                    lw=1.5, color=col, label=f'r = {r}')

    ax.set_xlabel('Coupling  ε')
    ax.set_ylabel('Spatial variance  Var(x)  [log]')
    ax.set_title('Synchronisation in Ring CML: spatial variance vs ε')
    ax.legend(fontsize=9)
    plt.tight_layout()
    plt.savefig('/mnt/user-data/outputs/B2_sync_vs_eps_ring.png', bbox_inches='tight')
    plt.show()

    # ── B3: Spatial correlation C(d) ─────────────────────────────────────────
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    for ax, (r, eps, lbl) in zip(axes, [(2.9, 0.1, 'Chaotic'), (2.0, 0.5, 'Sync')]):
        x = np.random.uniform(0.5, 2.5, N)
        for _ in range(N_trans2):
            x = cml_ring_step(x, r, eps)
        snapshots = []
        for _ in range(500):
            x = cml_ring_step(x, r, eps)
            snapshots.append(x.copy())
        snapshots = np.array(snapshots)   # (T, N)
        # Correlation at distance d
        C_d = []
        for d in range(N // 2):
            corr = np.mean([np.corrcoef(snapshots[:, i],
                            snapshots[:, (i + d) % N])[0, 1]
                            for i in range(0, N, 5)])
            C_d.append(corr)
        ax.plot(range(N // 2), C_d, color='steelblue', lw=1.5)
        ax.axhline(0, color='k', ls='--', lw=0.8)
        ax.set_xlabel('Distance  d'); ax.set_ylabel('C(d)')
        ax.set_title(f'Spatial correlation  ({lbl}: r={r}, ε={eps})')
    plt.tight_layout()
    plt.savefig('/mnt/user-data/outputs/B3_spatial_correlation.png', bbox_inches='tight')
    plt.show()
    print("  → Saved: B1, B2, B3")


# =============================================================================
# EXPERIMENT C — Network-coupled CML (WS / BA / fully connected)
# =============================================================================

def cml_network_step(x, r, eps, A, k_deg):
    """
    One step of network-coupled CML.

    x_{i,n+1} = (1 - ε) f(x_{i,n}) + (ε / k_i) Σ_j A_ij f(x_{j,n})

    Parameters
    ----------
    x     : array (N,)
    r     : float
    eps   : float  — coupling strength
    A     : (N,N) adjacency matrix
    k_deg : array (N,) — degree of each node
    """
    fx = ricker(x, r)
    # Weighted sum of neighbours' mapped values
    neighbour_sum = A @ fx                          # shape (N,)
    k_safe = np.where(k_deg > 0, k_deg, 1)         # avoid division by zero
    return (1 - eps) * fx + eps * neighbour_sum / k_safe


def build_networks(N):
    """Build three network types for comparison."""
    # WS small-world
    G_ws = nx.watts_strogatz_graph(N, 6, 0.1, seed=42)
    # Barabási–Albert scale-free
    G_ba = nx.barabasi_albert_graph(N, 3, seed=42)
    # Ring (1D lattice, k=6)
    G_ring = nx.watts_strogatz_graph(N, 6, 0.0, seed=42)

    nets = {}
    for name, G in [('Ring (p=0)', G_ring),
                    ('WS small-world', G_ws),
                    ('Scale-free (BA)', G_ba)]:
        A = nx.to_numpy_array(G)
        k = A.sum(axis=1)
        nets[name] = (G, A, k)
    return nets


def experiment_C_network_CML():
    """
    C1. Space-time plots for three network topologies.
    C2. Synchronisation (variance vs ε) for all three networks.
    C3. Network visualisation coloured by steady-state x value.
    """
    print("\n[C] Network-coupled CML: WS / BA / Ring")

    N       = 80
    N_trans = 600
    N_iter  = 300
    nets    = build_networks(N)

    # ── C1: Space-time plots ──────────────────────────────────────────────────
    r, eps = 2.7, 0.3
    fig, axes = plt.subplots(1, 3, figsize=(16, 6))
    fig.suptitle(f'Space-time plots — Network CML  (r={r}, ε={eps})',
                 fontsize=13, fontweight='bold')

    for ax, (name, (G, A, k)) in zip(axes, nets.items()):
        x = np.random.uniform(0.5, 2.5, N)
        for _ in range(N_trans):
            x = cml_network_step(x, r, eps, A, k)
        XT = []
        for _ in range(N_iter):
            x = cml_network_step(x, r, eps, A, k)
            XT.append(x.copy())
        XT = np.array(XT).T
        im = ax.imshow(XT, aspect='auto', origin='lower',
                       extent=[0, N_iter, 0, N], cmap='inferno')
        ax.set_xlabel('Time  n'); ax.set_ylabel('Node  i')
        ax.set_title(name, fontsize=11)
        plt.colorbar(im, ax=ax, label='$x_i$')

    plt.tight_layout()
    plt.savefig('/mnt/user-data/outputs/C1_spacetime_networks.png', bbox_inches='tight')
    plt.show()

    # ── C2: Synchronisation vs ε for all networks ─────────────────────────────
    eps_vals = np.linspace(0, 0.9, 35)
    r_test   = 2.7
    colors2  = ['steelblue', 'darkorange', 'crimson']
    N_trans3, N_iter3 = 800, 500

    fig, ax = plt.subplots(figsize=(9, 5))
    for (name, (G, A, k)), col in zip(nets.items(), colors2):
        sync = []
        for eps in eps_vals:
            x = np.random.uniform(0.5, 2.5, N)
            for _ in range(N_trans3):
                x = cml_network_step(x, r_test, eps, A, k)
            variances = []
            for _ in range(N_iter3):
                x = cml_network_step(x, r_test, eps, A, k)
                variances.append(np.var(x))
            sync.append(np.mean(variances))
        ax.semilogy(eps_vals, np.array(sync) + 1e-12, '-o', ms=4,
                    lw=1.8, color=col, label=name)

    ax.set_xlabel('Coupling strength  ε')
    ax.set_ylabel('Spatial variance  Var(x)  [log scale]')
    ax.set_title(f'Synchronisation vs ε for different topologies  (r={r_test})')
    ax.legend()
    plt.tight_layout()
    plt.savefig('/mnt/user-data/outputs/C2_sync_vs_eps_networks.png', bbox_inches='tight')
    plt.show()

    # ── C3: Network visualisation coloured by x_i ────────────────────────────
    r_vis, eps_vis = 2.7, 0.2
    fig, axes = plt.subplots(1, 3, figsize=(16, 5))
    fig.suptitle(f'Node state $x_i$ after transient  (r={r_vis}, ε={eps_vis})',
                 fontsize=12, fontweight='bold')

    for ax, (name, (G, A, k)), col_map in zip(axes, nets.items(),
                                               ['viridis', 'plasma', 'magma']):
        x = np.random.uniform(0.5, 2.5, N)
        for _ in range(1000):
            x = cml_network_step(x, r_vis, eps_vis, A, k)

        if N <= 80:
            pos = nx.spring_layout(G, seed=42)
        else:
            pos = nx.kamada_kawai_layout(G)

        nx.draw_networkx_edges(G, pos, ax=ax, alpha=0.15, width=0.5, edge_color='gray')
        sc = nx.draw_networkx_nodes(G, pos, ax=ax,
                                    node_color=x, cmap=col_map,
                                    node_size=60, vmin=x.min(), vmax=x.max())
        ax.set_title(name); ax.axis('off')
        plt.colorbar(sc, ax=ax, label='$x_i$')

    plt.tight_layout()
    plt.savefig('/mnt/user-data/outputs/C3_network_state.png', bbox_inches='tight')
    plt.show()
    print("  → Saved: C1, C2, C3")


# =============================================================================
# EXPERIMENT D — Phase diagram in (r, ε) space
# =============================================================================

def experiment_D_phase_diagram():
    """
    Sweep the (r, ε) parameter plane for the ring CML.
    Classify each point as:
      - Synchronised:     Var(x) < threshold_low
      - Periodic:         low variance but not zero, time-average periodic
      - Spatiotemporal chaos: Var(x) > threshold_high

    Colour-map the spatial variance to reveal the phase structure.
    """
    print("\n[D] Phase diagram in (r, ε) space")

    N        = 60
    N_trans  = 500
    N_iter   = 300
    r_vals   = np.linspace(1.0, 3.0, 60)
    eps_vals = np.linspace(0.0, 1.0, 60)
    VAR      = np.zeros((len(eps_vals), len(r_vals)))

    for j, r in enumerate(r_vals):
        for i, eps in enumerate(eps_vals):
            x = np.random.uniform(0.5, 2.5, N)
            for _ in range(N_trans):
                x = cml_ring_step(x, r, eps)
            vars_ = []
            for _ in range(N_iter):
                x = cml_ring_step(x, r, eps)
                vars_.append(np.var(x))
            VAR[i, j] = np.mean(vars_)

    fig, ax = plt.subplots(figsize=(10, 7))
    im = ax.pcolormesh(r_vals, eps_vals, np.log10(VAR + 1e-10),
                       cmap='RdYlBu_r', shading='auto')
    cb = plt.colorbar(im, ax=ax)
    cb.set_label('log₁₀  Spatial variance  Var(x)', fontsize=11)
    ax.set_xlabel('Parameter  r',  fontsize=12)
    ax.set_ylabel('Coupling  ε',   fontsize=12)
    ax.set_title('Phase diagram of Ring CML\n'
                 'Blue = synchronised,  Red = spatiotemporal chaos',
                 fontsize=12, fontweight='bold')

    # Annotate regions
    ax.text(1.4, 0.8, 'SYNC', color='white',  fontsize=14, fontweight='bold', ha='center')
    ax.text(2.8, 0.1, 'CHAOS', color='white', fontsize=14, fontweight='bold', ha='center')
    ax.text(2.0, 0.5, 'COMPLEX\nPATTERNS', color='white', fontsize=11, ha='center')

    plt.tight_layout()
    plt.savefig('/mnt/user-data/outputs/D_phase_diagram.png', bbox_inches='tight')
    plt.show()
    print("  → Saved: D_phase_diagram.png")


# =============================================================================
# EXPERIMENT E — Chimera-like states and cluster synchronisation
# =============================================================================

def experiment_E_chimera():
    """
    With carefully chosen initial conditions, coupled chaotic maps can show
    chimera-like states: some nodes synchronised, others chaotic.
    Also show cluster synchronisation (two groups).
    """
    print("\n[E] Chimera-like and cluster synchronisation states")

    N       = 100
    N_trans = 300
    N_iter  = 400

    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    fig.suptitle('Chimera-like and cluster states in Ring CML',
                 fontsize=13, fontweight='bold')

    scenarios = [
        # (r, eps, IC_type, title)
        (2.5, 0.3, 'uniform',  'r=2.5, ε=0.3 — uniform IC'),
        (2.5, 0.3, 'bimodal',  'r=2.5, ε=0.3 — bimodal IC (clusters)'),
        (2.9, 0.15, 'chimera', 'r=2.9, ε=0.15 — chimera-like IC'),
        (2.9, 0.4,  'uniform', 'r=2.9, ε=0.4 — high coupling'),
    ]

    for ax, (r, eps, ic, title) in zip(axes.flat, scenarios):
        if ic == 'uniform':
            x = np.random.uniform(0.5, 2.5, N)
        elif ic == 'bimodal':
            x = np.concatenate([
                np.random.uniform(0.5, 1.0, N // 2),
                np.random.uniform(2.0, 2.5, N // 2)
            ])
        else:  # chimera
            x = np.ones(N) * 1.5
            x[N//2:] += np.random.uniform(-0.5, 0.5, N // 2)

        for _ in range(N_trans):
            x = cml_ring_step(x, r, eps)

        XT = []
        for _ in range(N_iter):
            x = cml_ring_step(x, r, eps)
            XT.append(x.copy())
        XT = np.array(XT).T

        im = ax.imshow(XT, aspect='auto', origin='lower',
                       extent=[0, N_iter, 0, N], cmap='viridis')
        ax.set_xlabel('Time  n'); ax.set_ylabel('Site  i')
        ax.set_title(title, fontsize=10)
        plt.colorbar(im, ax=ax, label='$x_i$')

    plt.tight_layout()
    plt.savefig('/mnt/user-data/outputs/E_chimera.png', bbox_inches='tight')
    plt.show()
    print("  → Saved: E_chimera.png")


# =============================================================================
# EXPERIMENT F — Information theory: Spatial entropy
# =============================================================================

def spatial_entropy(x, bins=20):
    """
    Approximate spatial Shannon entropy H = -Σ p_k log(p_k)
    from histogram of x values across sites.
    High H ≈ disorder/chaos; Low H ≈ synchronised/periodic.
    """
    hist, _ = np.histogram(x, bins=bins, range=(0, 5), density=True)
    hist = hist[hist > 0]
    return -np.sum(hist * np.log(hist)) * (5 / bins)


def experiment_F_entropy():
    """
    F1. Spatial entropy H(t) over time for different (r, ε).
    F2. Mean entropy H̄ vs r (entropy collapses at synchronisation).
    """
    print("\n[F] Spatial entropy analysis")

    N = 80; N_trans = 400; N_iter = 500

    # ── F1: H(t) trajectories ─────────────────────────────────────────────────
    fig, ax = plt.subplots(figsize=(11, 5))
    configs = [
        (2.0, 0.6, 'steelblue',  'r=2.0, ε=0.6 (sync)'),
        (2.5, 0.2, 'darkorange', 'r=2.5, ε=0.2 (complex)'),
        (2.9, 0.1, 'crimson',    'r=2.9, ε=0.1 (chaos)'),
    ]
    for r, eps, col, lbl in configs:
        x = np.random.uniform(0.5, 2.5, N)
        for _ in range(N_trans):
            x = cml_ring_step(x, r, eps)
        H = []
        for _ in range(N_iter):
            x = cml_ring_step(x, r, eps)
            H.append(spatial_entropy(x))
        ax.plot(H, color=col, lw=1.2, alpha=0.85, label=lbl)
    ax.set_xlabel('Time step  n'); ax.set_ylabel('Spatial entropy  H(t)')
    ax.set_title('Spatial entropy over time — Ring CML')
    ax.legend()
    plt.tight_layout()
    plt.savefig('/mnt/user-data/outputs/F1_entropy_time.png', bbox_inches='tight')
    plt.show()

    # ── F2: H̄ vs r ────────────────────────────────────────────────────────────
    r_scan   = np.linspace(1.0, 3.0, 60)
    eps_list = [0.1, 0.3, 0.6]
    colors   = ['crimson', 'darkorange', 'steelblue']

    fig, ax = plt.subplots(figsize=(10, 5))
    for eps, col in zip(eps_list, colors):
        H_means = []
        for r in r_scan:
            x = np.random.uniform(0.5, 2.5, N)
            for _ in range(N_trans):
                x = cml_ring_step(x, r, eps)
            H = []
            for _ in range(300):
                x = cml_ring_step(x, r, eps)
                H.append(spatial_entropy(x))
            H_means.append(np.mean(H))
        ax.plot(r_scan, H_means, color=col, lw=1.8, label=f'ε = {eps}')

    ax.set_xlabel('Parameter  r'); ax.set_ylabel('Mean spatial entropy  H̄')
    ax.set_title('Mean spatial entropy H̄ vs r  (Ring CML, N=80)')
    ax.legend()
    plt.tight_layout()
    plt.savefig('/mnt/user-data/outputs/F2_entropy_vs_r.png', bbox_inches='tight')
    plt.show()
    print("  → Saved: F1, F2")


# =============================================================================
# EXPERIMENT G — Lyapunov spectrum of coupled system
# =============================================================================

def experiment_G_max_lyapunov_CML():
    """
    Estimate the maximum Lyapunov exponent of the coupled system
    (ring CML) by tracking divergence of nearby trajectories.

    λ_max > 0 → spatiotemporal chaos
    λ_max < 0 → synchronised / stable
    λ_max = 0 → at edge of chaos / bifurcation

    Plot λ_max as a 2D heatmap over (r, ε).
    """
    print("\n[G] Maximum Lyapunov exponent of ring CML  (r, ε) scan")

    N        = 40
    N_trans  = 300
    N_iter   = 400
    delta0   = 1e-8

    r_vals   = np.linspace(1.0, 3.0, 40)
    eps_vals = np.linspace(0.0, 0.9, 40)
    LAMBDA   = np.zeros((len(eps_vals), len(r_vals)))

    for j, r in enumerate(r_vals):
        for i, eps in enumerate(eps_vals):
            x = np.random.uniform(0.5, 2.5, N)
            for _ in range(N_trans):
                x = cml_ring_step(x, r, eps)

            # Perturbed trajectory
            dx = np.random.randn(N); dx /= np.linalg.norm(dx)
            xp = x + delta0 * dx

            lam_sum = 0.0
            for _ in range(N_iter):
                x  = cml_ring_step(x,  r, eps)
                xp = cml_ring_step(xp, r, eps)
                d  = np.linalg.norm(xp - x)
                if d > 0:
                    lam_sum += np.log(d / delta0)
                    xp = x + (xp - x) * delta0 / d
            LAMBDA[i, j] = lam_sum / N_iter

    fig, ax = plt.subplots(figsize=(10, 7))
    im = ax.pcolormesh(r_vals, eps_vals, LAMBDA,
                       cmap='RdBu_r', shading='auto',
                       vmin=-1, vmax=1)
    cb = plt.colorbar(im, ax=ax)
    cb.set_label('Max Lyapunov exponent  λ_max', fontsize=11)
    ax.contour(r_vals, eps_vals, LAMBDA, levels=[0],
               colors='black', linewidths=1.5, linestyles='--')
    ax.set_xlabel('Parameter  r',  fontsize=12)
    ax.set_ylabel('Coupling  ε',   fontsize=12)
    ax.set_title('Maximum Lyapunov exponent of Ring CML\n'
                 'Red = chaos (λ>0),  Blue = stable (λ<0),  Dashed = λ=0 boundary',
                 fontsize=12, fontweight='bold')
    plt.tight_layout()
    plt.savefig('/mnt/user-data/outputs/G_max_lyapunov.png', bbox_inches='tight')
    plt.show()
    print("  → Saved: G_max_lyapunov.png")


# =============================================================================
# EXPERIMENT H — Degree heterogeneity: hub nodes synchronise first (BA net)
# =============================================================================

def experiment_H_hub_synchronisation():
    """
    On a scale-free (BA) network, high-degree hub nodes tend to
    synchronise first. Track x_i(t) for hubs vs peripheral nodes.
    """
    print("\n[H] Hub vs peripheral node dynamics (BA scale-free CML)")

    N     = 80
    r     = 2.7
    eps   = 0.25
    G_ba  = nx.barabasi_albert_graph(N, 3, seed=42)
    A_ba  = nx.to_numpy_array(G_ba)
    k_ba  = A_ba.sum(axis=1)

    # Identify top-5 hubs and 5 low-degree nodes
    deg_sorted = np.argsort(k_ba)[::-1]
    hubs   = deg_sorted[:5]
    leaves = deg_sorted[-5:]

    x = np.random.uniform(0.5, 2.5, N)
    N_trans, N_iter = 200, 600

    for _ in range(N_trans):
        x = cml_network_step(x, r, eps, A_ba, k_ba)

    X_hist = np.zeros((N, N_iter))
    for t in range(N_iter):
        x = cml_network_step(x, r, eps, A_ba, k_ba)
        X_hist[:, t] = x

    fig, axes = plt.subplots(2, 1, figsize=(13, 9), sharex=True)
    fig.suptitle(f'Hub vs leaf node dynamics — BA scale-free CML  (r={r}, ε={eps})',
                 fontsize=12, fontweight='bold')

    colors_h = plt.cm.Reds(np.linspace(0.5, 0.9, len(hubs)))
    colors_l = plt.cm.Blues(np.linspace(0.5, 0.9, len(leaves)))

    for idx, (node, col) in enumerate(zip(hubs, colors_h)):
        axes[0].plot(X_hist[node], color=col, lw=1.2, alpha=0.85,
                     label=f'Hub {node} (k={int(k_ba[node])})')
    axes[0].set_ylabel('$x_i(t)$'); axes[0].set_title('Hub nodes (high degree)')
    axes[0].legend(fontsize=8, ncol=2)

    for idx, (node, col) in enumerate(zip(leaves, colors_l)):
        axes[1].plot(X_hist[node], color=col, lw=1.2, alpha=0.85,
                     label=f'Leaf {node} (k={int(k_ba[node])})')
    axes[1].set_xlabel('Time step  n')
    axes[1].set_ylabel('$x_i(t)$'); axes[1].set_title('Leaf nodes (low degree)')
    axes[1].legend(fontsize=8, ncol=2)

    plt.tight_layout()
    plt.savefig('/mnt/user-data/outputs/H_hub_dynamics.png', bbox_inches='tight')
    plt.show()

    # Degree vs variance of node
    x = np.random.uniform(0.5, 2.5, N)
    for _ in range(N_trans + 400):
        x = cml_network_step(x, r, eps, A_ba, k_ba)
    snapshots = []
    for _ in range(600):
        x = cml_network_step(x, r, eps, A_ba, k_ba)
        snapshots.append(x.copy())
    snapshots = np.array(snapshots)
    node_var  = np.var(snapshots, axis=0)

    fig2, ax2 = plt.subplots(figsize=(8, 5))
    ax2.scatter(k_ba, node_var, s=40, alpha=0.7, color='steelblue',
                edgecolors='navy', linewidths=0.4)
    ax2.set_xlabel('Node degree  k_i'); ax2.set_ylabel('Temporal variance  Var(x_i)')
    ax2.set_title(f'Node degree vs temporal variability  (r={r}, ε={eps})')
    # Correlation
    rho = np.corrcoef(k_ba, node_var)[0, 1]
    ax2.text(0.05, 0.92, f'Pearson r = {rho:.3f}', transform=ax2.transAxes,
             fontsize=11, color='crimson')
    plt.tight_layout()
    plt.savefig('/mnt/user-data/outputs/H2_degree_vs_variance.png', bbox_inches='tight')
    plt.show()
    print("  → Saved: H_hub_dynamics.png, H2_degree_vs_variance.png")


# =============================================================================
# EXPERIMENT I — Summary statistics dashboard
# =============================================================================

def experiment_I_summary_dashboard():
    """
    One-page dashboard showing all key results side by side.
    """
    print("\n[I] Summary dashboard")

    N = 60; N_trans = 500; N_iter = 300

    fig = plt.figure(figsize=(18, 12))
    fig.suptitle(
        'Coupled Ricker Maps — Summary Dashboard\n'
        r'$x_{n+1} = x_n^2 \exp(r - x_n)$   coupled on various networks',
        fontsize=14, fontweight='bold'
    )
    gs = gridspec.GridSpec(3, 4, figure=fig, hspace=0.45, wspace=0.4)

    # Panel 1: Bifurcation (single map)
    ax1 = fig.add_subplot(gs[0, :2])
    r_vals = np.linspace(1, 3, 800); N_tr2 = 400; N_pl2 = 100
    br, bx = [], []
    for r in r_vals:
        x = 1.5
        for _ in range(N_tr2): x = ricker(x, r)
        for _ in range(N_pl2):
            x = ricker(x, r); br.append(r); bx.append(x)
    ax1.scatter(br, bx, s=0.3, c='steelblue', alpha=0.4)
    ax1.set_xlabel('r'); ax1.set_ylabel('$x^*$')
    ax1.set_title('Single map bifurcation')

    # Panel 2: Lyapunov
    ax2 = fig.add_subplot(gs[0, 2:])
    lyap2 = []
    for r in r_vals:
        x = 1.5; lam = 0
        for _ in range(1500):
            lam += np.log(abs(ricker_deriv(x, r)) + 1e-16)
            x = ricker(x, r)
        lyap2.append(lam / 1500)
    lyap2 = np.array(lyap2)
    ax2.plot(r_vals, lyap2, color='darkviolet', lw=1)
    ax2.axhline(0, color='crimson', ls='--', lw=1)
    ax2.fill_between(r_vals, lyap2, 0, where=(lyap2>0), alpha=0.2, color='crimson')
    ax2.set_xlabel('r'); ax2.set_ylabel('λ'); ax2.set_title('Lyapunov exponent λ(r)')

    # Panel 3 & 4: Space-time for ring CML
    for col_idx, (r_st, eps_st, title_st) in enumerate(
        [(2.0, 0.5, 'Ring CML\nr=2.0, ε=0.5 (sync)'),
         (2.9, 0.1, 'Ring CML\nr=2.9, ε=0.1 (chaos)')]
    ):
        ax = fig.add_subplot(gs[1, col_idx * 2: col_idx * 2 + 2])
        x = np.random.uniform(0.5, 2.5, N)
        for _ in range(N_trans): x = cml_ring_step(x, r_st, eps_st)
        XT = []
        for _ in range(N_iter):
            x = cml_ring_step(x, r_st, eps_st); XT.append(x.copy())
        XT = np.array(XT).T
        im = ax.imshow(XT, aspect='auto', origin='lower',
                       extent=[0, N_iter, 0, N], cmap='inferno')
        ax.set_xlabel('n'); ax.set_ylabel('i'); ax.set_title(title_st, fontsize=10)
        fig.colorbar(im, ax=ax, fraction=0.03)

    # Panel 5: Sync vs ε (3 networks)
    ax5 = fig.add_subplot(gs[2, :2])
    N2   = 60; r_s = 2.7
    nets = build_networks(N2)
    eps_v = np.linspace(0, 0.9, 25)
    for (nm, (G, A, k)), col in zip(nets.items(), ['steelblue', 'darkorange', 'crimson']):
        sv = []
        for eps in eps_v:
            x = np.random.uniform(0.5, 2.5, N2)
            for _ in range(600): x = cml_network_step(x, r_s, eps, A, k)
            vv = []
            for _ in range(300):
                x = cml_network_step(x, r_s, eps, A, k); vv.append(np.var(x))
            sv.append(np.mean(vv))
        ax5.semilogy(eps_v, np.array(sv)+1e-12, '-o', ms=3, lw=1.5, color=col, label=nm)
    ax5.set_xlabel('ε'); ax5.set_ylabel('Var(x) [log]')
    ax5.set_title(f'Sync vs ε, 3 topologies (r={r_s})'); ax5.legend(fontsize=8)

    # Panel 6: Entropy vs r
    ax6 = fig.add_subplot(gs[2, 2:])
    r_sc = np.linspace(1.0, 3.0, 40)
    for eps_e, col_e in zip([0.1, 0.5], ['crimson', 'steelblue']):
        H_m = []
        for r in r_sc:
            x = np.random.uniform(0.5, 2.5, N)
            for _ in range(N_trans): x = cml_ring_step(x, r, eps_e)
            H = [spatial_entropy(cml_ring_step.__wrapped__(x, r, eps_e)
                                 if hasattr(cml_ring_step, '__wrapped__')
                                 else (cml_ring_step(x, r, eps_e), x := cml_ring_step(x, r, eps_e))[1])
                 for _ in range(200)] if False else []
            for _ in range(200):
                x = cml_ring_step(x, r, eps_e); H.append(spatial_entropy(x))
            H_m.append(np.mean(H))
        ax6.plot(r_sc, H_m, color=col_e, lw=1.5, label=f'ε={eps_e}')
    ax6.set_xlabel('r'); ax6.set_ylabel('H̄'); ax6.set_title('Spatial entropy vs r')
    ax6.legend(fontsize=9)

    plt.savefig('/mnt/user-data/outputs/I_summary_dashboard.png', bbox_inches='tight')
    plt.show()
    print("  → Saved: I_summary_dashboard.png")


# =============================================================================
# MAIN
# =============================================================================

if __name__ == '__main__':

    print("=" * 65)
    print("  COUPLED RICKER MAPS — FULL EXPLORATION")
    print("  Local map:  x_{n+1} = x_n^2 * exp(r - x_n)")
    print("  r ∈ [1, 3],  x > 0")
    print("=" * 65)

    experiment_A_single_map()           # Bifurcation, Lyapunov, cobweb
    experiment_B_ring_CML()             # 1D ring coupling, space-time, sync
    experiment_C_network_CML()          # WS / BA / Ring comparison
    experiment_D_phase_diagram()        # (r, ε) phase diagram
    experiment_E_chimera()              # Chimera-like states
    experiment_F_entropy()              # Spatial entropy analysis
    experiment_G_max_lyapunov_CML()     # Max Lyapunov heatmap
    experiment_H_hub_synchronisation()  # Hubs synchronise first
    experiment_I_summary_dashboard()    # One-page summary

    print("\n" + "=" * 65)
    print("  ALL EXPERIMENTS COMPLETE")
    print("  Output files in /mnt/user-data/outputs/")
    print("=" * 65)