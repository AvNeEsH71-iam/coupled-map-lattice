"""Analysis routines for map dynamics, chaos metrics, and synchronization."""

from __future__ import annotations

import numpy as np
import pandas as pd

from cml import simulate_cml
from map_model import iterate_map, local_map, lyapunov_exponent


def single_map_bifurcation(
    r_values: np.ndarray,
    x0: float,
    n_transient: int,
    n_keep: int,
) -> pd.DataFrame:
    """Build raw bifurcation data for the local map."""

    rows: list[dict[str, float]] = []
    for r in r_values:
        x = max(x0, 1e-12)
        for _ in range(n_transient):
            x = max(local_map(x, float(r)), 1e-12)
        for n_idx in range(n_keep):
            x = max(local_map(x, float(r)), 1e-12)
            rows.append({"r": float(r), "k": float(n_idx), "x": float(x)})
    return pd.DataFrame(rows)


def lyapunov_scan(r_values: np.ndarray, x0: float, n_transient: int, n_measure: int) -> pd.DataFrame:
    """Estimate Lyapunov exponent across parameter values."""

    lambdas = [lyapunov_exponent(float(r), x0, n_transient, n_measure) for r in r_values]
    return pd.DataFrame({"r": r_values, "lambda": np.array(lambdas, dtype=float)})


def fixed_point_stability_scan(r_values: np.ndarray) -> pd.DataFrame:
    """Evaluate map fixed points and linear stability multipliers."""

    from map_model import fixed_points

    rows: list[dict[str, float | None]] = []
    for r in r_values:
        fp = fixed_points(float(r))
        row = {
            "r": float(r),
            "x0": float(fp["x0"]),
            "x0_multiplier": float(fp["x0_multiplier"]),
            "x_minus": fp["x_minus"],
            "x_minus_multiplier": fp["x_minus_multiplier"],
            "x_plus": fp["x_plus"],
            "x_plus_multiplier": fp["x_plus_multiplier"],
        }
        rows.append(row)
    return pd.DataFrame(rows)


def synchronization_error(traj: np.ndarray) -> np.ndarray:
    """Compute synchronization error E(n) as RMS spread from lattice mean."""

    mean_state = np.mean(traj, axis=1, keepdims=True)
    return np.sqrt(np.mean((traj - mean_state) ** 2, axis=1))


def sync_regime_from_error(error_tail_mean: float, no_sync: float = 0.25, full_sync: float = 0.03) -> str:
    """Classify synchronization regime from long-time error level."""

    if error_tail_mean >= no_sync:
        return "no_sync"
    if error_tail_mean <= full_sync:
        return "full_sync"
    return "partial_sync"


def cml_epsilon_sweep(
    adjacency: np.ndarray,
    r: float,
    epsilon_values: np.ndarray,
    n_steps: int,
    x0: np.ndarray,
    transient_fraction: float = 0.6,
) -> pd.DataFrame:
    """Sweep coupling and return summary metrics for synchronization study."""

    rows: list[dict[str, float | str]] = []
    tail_start = int(transient_fraction * n_steps)

    for eps in epsilon_values:
        traj = simulate_cml(r=r, epsilon=float(eps), adjacency=adjacency, n_steps=n_steps, x0=x0)
        err = synchronization_error(traj)
        tail_err = err[tail_start:]
        rows.append(
            {
                "epsilon": float(eps),
                "error_tail_mean": float(np.mean(tail_err)),
                "error_tail_std": float(np.std(tail_err)),
                "x_tail_var": float(np.var(traj[tail_start:])),
                "regime": sync_regime_from_error(float(np.mean(tail_err))),
            }
        )

    return pd.DataFrame(rows)


def cluster_coherence(traj: np.ndarray, n_clusters: int = 4, transient_fraction: float = 0.6) -> pd.DataFrame:
    """Measure cluster-level synchronization using contiguous index blocks."""

    n_nodes = traj.shape[1]
    tail_start = int(transient_fraction * (traj.shape[0] - 1))
    blocks = np.array_split(np.arange(n_nodes), n_clusters)

    rows: list[dict[str, float]] = []
    for idx, block in enumerate(blocks):
        signal = traj[tail_start:, block]
        block_mean = np.mean(signal, axis=1, keepdims=True)
        block_error = float(np.mean(np.sqrt(np.mean((signal - block_mean) ** 2, axis=1))))
        rows.append({"cluster": float(idx), "size": float(len(block)), "cluster_error": block_error})

    return pd.DataFrame(rows)


def size_effect_experiment(
    sizes: list[int],
    r: float,
    epsilon: float,
    n_steps: int,
    seed: int,
) -> pd.DataFrame:
    """Quantify synchronization scaling with system size N on a ring."""

    from cml import ring_adjacency

    rng = np.random.default_rng(seed)
    rows: list[dict[str, float]] = []

    for n_nodes in sizes:
        adjacency = ring_adjacency(n_nodes)
        x0 = 0.8 + 0.4 * rng.random(n_nodes)
        traj = simulate_cml(r=r, epsilon=epsilon, adjacency=adjacency, n_steps=n_steps, x0=x0)
        err = synchronization_error(traj)
        rows.append(
            {
                "N": float(n_nodes),
                "error_final": float(err[-1]),
                "error_tail_mean": float(np.mean(err[int(0.6 * n_steps) :])),
                "state_tail_var": float(np.var(traj[int(0.6 * n_steps) :])),
            }
        )

    return pd.DataFrame(rows)


def representative_single_map_series(r_values: list[float], x0: float, n_steps: int) -> pd.DataFrame:
    """Generate compact time series for selected r values."""

    rows: list[dict[str, float]] = []
    for r in r_values:
        x = iterate_map(r=float(r), x0=x0, n_steps=n_steps)
        for n_idx, value in enumerate(x):
            rows.append({"r": float(r), "n": float(n_idx), "x": float(value)})
    return pd.DataFrame(rows)
