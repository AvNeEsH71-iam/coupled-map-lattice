"""Plotting utilities for CML coursework outputs."""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


PLOT_DPI = 300


def save_fig(fig: plt.Figure, path: Path) -> None:
    """Save figure at high resolution and close handle."""

    path.parent.mkdir(parents=True, exist_ok=True)
    fig.tight_layout()
    fig.savefig(path, dpi=PLOT_DPI, bbox_inches="tight")
    plt.close(fig)


def set_style() -> None:
    """Set publication-friendly style defaults."""

    plt.style.use("seaborn-v0_8-whitegrid")
    plt.rcParams.update(
        {
            "font.size": 11,
            "axes.labelsize": 11,
            "axes.titlesize": 12,
            "legend.fontsize": 9,
        }
    )


def plot_single_map_timeseries(df: pd.DataFrame) -> plt.Figure:
    fig, ax = plt.subplots(figsize=(8.5, 4.8))
    for r in sorted(df["r"].unique()):
        subset = df[df["r"] == r]
        ax.plot(subset["n"], subset["x"], lw=1.4, label=f"r={r:.2f}")
    ax.set_xlabel("Iteration n")
    ax.set_ylabel("x_n")
    ax.set_title("Single-map dynamics for representative r values")
    ax.legend(ncol=2)
    return fig


def plot_phase_space(df: pd.DataFrame, r_value: float) -> plt.Figure:
    subset = df[df["r"] == r_value]
    x = subset["x"].to_numpy()
    fig, ax = plt.subplots(figsize=(5.8, 5.2))
    ax.scatter(x[:-1], x[1:], s=10, alpha=0.55, color="#1f77b4")
    ax.set_xlabel("x_n")
    ax.set_ylabel("x_{n+1}")
    ax.set_title(f"Phase-space map at r={r_value:.2f}")
    return fig


def plot_bifurcation(df: pd.DataFrame) -> plt.Figure:
    fig, ax = plt.subplots(figsize=(9, 5))
    ax.scatter(df["r"], df["x"], s=0.5, color="black", alpha=0.4, rasterized=True)
    ax.set_xlabel("r")
    ax.set_ylabel("Asymptotic x")
    ax.set_title("Bifurcation diagram of x_{n+1}=x_n^2 exp(r-x_n)")
    return fig


def plot_lyapunov(df: pd.DataFrame) -> plt.Figure:
    fig, ax = plt.subplots(figsize=(9, 4.6))
    ax.plot(df["r"], df["lambda"], color="#d62728", lw=1.8)
    ax.axhline(0.0, color="black", lw=1.0, ls="--")
    ax.set_xlabel("r")
    ax.set_ylabel("Lyapunov exponent")
    ax.set_title("Lyapunov spectrum of the local map")
    return fig


def plot_sync_error_vs_epsilon(df: pd.DataFrame) -> plt.Figure:
    color_map = {"no_sync": "#d62728", "partial_sync": "#ff7f0e", "full_sync": "#2ca02c"}
    fig, ax = plt.subplots(figsize=(8.5, 4.8))

    for regime in ["no_sync", "partial_sync", "full_sync"]:
        subset = df[df["regime"] == regime]
        if subset.empty:
            continue
        ax.scatter(
            subset["epsilon"],
            subset["error_tail_mean"],
            s=30,
            color=color_map[regime],
            label=regime.replace("_", " "),
        )

    ax.plot(df["epsilon"], df["error_tail_mean"], color="#1f77b4", alpha=0.6, lw=1.2)
    ax.set_xlabel("Coupling strength epsilon")
    ax.set_ylabel("Tail mean synchronization error")
    ax.set_title("Synchronization transition versus coupling")
    ax.legend()
    return fig


def plot_spatiotemporal(traj: np.ndarray, title: str) -> plt.Figure:
    fig, ax = plt.subplots(figsize=(9, 4.8))
    im = ax.imshow(traj.T, aspect="auto", origin="lower", cmap="viridis")
    ax.set_xlabel("Iteration n")
    ax.set_ylabel("Node index")
    ax.set_title(title)
    cbar = fig.colorbar(im, ax=ax)
    cbar.set_label("x_i(n)")
    return fig


def plot_heatmap(traj: np.ndarray, title: str) -> plt.Figure:
    fig, ax = plt.subplots(figsize=(9, 5.2))
    im = ax.imshow(traj.T, aspect="auto", origin="lower", cmap="magma")
    ax.set_xlabel("Iteration n")
    ax.set_ylabel("Node index")
    ax.set_title(title)
    cbar = fig.colorbar(im, ax=ax)
    cbar.set_label("x_i(n)")
    return fig


def plot_topology_comparison(results: dict[str, pd.DataFrame]) -> plt.Figure:
    fig, ax = plt.subplots(figsize=(8.6, 4.8))
    for label, frame in results.items():
        ax.plot(frame["epsilon"], frame["error_tail_mean"], marker="o", ms=3, lw=1.4, label=label)
    ax.set_xlabel("epsilon")
    ax.set_ylabel("Tail mean synchronization error")
    ax.set_title("Topology effect on synchronization")
    ax.legend()
    return fig


def plot_cluster_bars(df: pd.DataFrame) -> plt.Figure:
    fig, ax = plt.subplots(figsize=(6.6, 4.4))
    ax.bar(df["cluster"].astype(int), df["cluster_error"], color="#9467bd")
    ax.set_xlabel("Cluster index")
    ax.set_ylabel("Cluster synchronization error")
    ax.set_title("Cluster synchronization profile")
    return fig


def plot_size_effect(df: pd.DataFrame) -> plt.Figure:
    fig, ax = plt.subplots(figsize=(7, 4.4))
    ax.plot(df["N"], df["error_tail_mean"], marker="s", lw=1.6, color="#8c564b")
    ax.set_xlabel("System size N")
    ax.set_ylabel("Tail mean synchronization error")
    ax.set_title("Finite-size effect on synchronization")
    return fig


def copy_for_report(src_paths: list[Path], report_fig_dir: Path) -> None:
    """Copy selected figures to report/figures for LaTeX inclusion."""

    import shutil

    report_fig_dir.mkdir(parents=True, exist_ok=True)
    for src in src_paths:
        if src.exists():
            shutil.copy2(src, report_fig_dir / src.name)
